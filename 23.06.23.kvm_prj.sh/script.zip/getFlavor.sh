#!/bin/bash

mysql  kvmdb -u root -ptest1234 -e "SELECT * FROM flavorTBL"
