-- MariaDB dump 10.19  Distrib 10.4.30-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: kvmdb
-- ------------------------------------------------------
-- Server version	10.4.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flavorTBL`
--

DROP TABLE IF EXISTS `flavorTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flavorTBL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` char(15) DEFAULT NULL,
  `CPU` varchar(10) DEFAULT NULL,
  `RAM` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flavorTBL`
--

LOCK TABLES `flavorTBL` WRITE;
/*!40000 ALTER TABLE `flavorTBL` DISABLE KEYS */;
INSERT INTO `flavorTBL` VALUES (1,'m1.small','1','1024'),(2,'m1.medium','2','2048');
/*!40000 ALTER TABLE `flavorTBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostTBL`
--

DROP TABLE IF EXISTS `hostTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostTBL` (
  `id` int(11) NOT NULL,
  `name` char(10) DEFAULT NULL,
  `zone` char(10) DEFAULT NULL,
  `ip` char(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostTBL`
--

LOCK TABLES `hostTBL` WRITE;
/*!40000 ALTER TABLE `hostTBL` DISABLE KEYS */;
/*!40000 ALTER TABLE `hostTBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imgTBL`
--

DROP TABLE IF EXISTS `imgTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imgTBL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `OS` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imgTBL`
--

LOCK TABLES `imgTBL` WRITE;
/*!40000 ALTER TABLE `imgTBL` DISABLE KEYS */;
INSERT INTO `imgTBL` VALUES (1,'Ubuntu'),(2,'CentOS 7'),(3,'Cirros');
/*!40000 ALTER TABLE `imgTBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instanceTBL`
--

DROP TABLE IF EXISTS `instanceTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instanceTBL` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vmname` char(10) DEFAULT NULL,
  `osimg` int(11) DEFAULT NULL,
  `flavor` int(11) DEFAULT NULL,
  `hostid` int(11) DEFAULT NULL,
  `volid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `volid` (`volid`),
  KEY `hostid` (`hostid`),
  KEY `FK_instanceTBL_flavorTbl_id` (`flavor`),
  KEY `FK_instanceTBL_imgTbl_id` (`osimg`),
  CONSTRAINT `FK1_hostid` FOREIGN KEY (`hostid`) REFERENCES `hostTBL` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK2_volid` FOREIGN KEY (`volid`) REFERENCES `volumeTBL` (`volid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_instanceTBL_flavorTbl_id` FOREIGN KEY (`flavor`) REFERENCES `flavorTBL` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_instanceTBL_imgTbl_id` FOREIGN KEY (`osimg`) REFERENCES `imgTBL` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instanceTBL`
--

LOCK TABLES `instanceTBL` WRITE;
/*!40000 ALTER TABLE `instanceTBL` DISABLE KEYS */;
/*!40000 ALTER TABLE `instanceTBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userTBL`
--

DROP TABLE IF EXISTS `userTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userTBL` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userTBL`
--

LOCK TABLES `userTBL` WRITE;
/*!40000 ALTER TABLE `userTBL` DISABLE KEYS */;
INSERT INTO `userTBL` VALUES (1,'user1','test1234');
/*!40000 ALTER TABLE `userTBL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumeTBL`
--

DROP TABLE IF EXISTS `volumeTBL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumeTBL` (
  `volid` int(11) NOT NULL AUTO_INCREMENT,
  `volname` char(15) DEFAULT NULL,
  `volsize` int(11) DEFAULT NULL,
  PRIMARY KEY (`volid`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumeTBL`
--

LOCK TABLES `volumeTBL` WRITE;
/*!40000 ALTER TABLE `volumeTBL` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumeTBL` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-22 18:07:49
